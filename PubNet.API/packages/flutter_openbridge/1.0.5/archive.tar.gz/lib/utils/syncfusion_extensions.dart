import 'package:flutter/painting.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

extension AxisLineStyleExtension on AxisLineStyle {
  AxisLineStyle copyWith({
    double? thickness,
    GaugeSizeUnit? thicknessUnit,
    CornerStyle? cornerStyle,
    Color? color,
    List<double>? dashArray,
    Gradient? gradient,
  }) {
    return AxisLineStyle(
      thickness: thickness ?? this.thickness,
      thicknessUnit: thicknessUnit ?? this.thicknessUnit,
      cornerStyle: cornerStyle ?? this.cornerStyle,
      color: color ?? this.color,
      dashArray: dashArray ?? this.dashArray,
      gradient: gradient ?? this.gradient,
    );
  }
}

extension RadialAxisExtension on RadialAxis {
  RadialAxis copyWith({
    AxisLineStyle? axisLineStyle,
    List<GaugePointer>? pointers,
    List<GaugeAnnotation>? annotations,
  }) {
    return RadialAxis(
      startAngle: this.startAngle,
      endAngle: this.endAngle,
      radiusFactor: this.radiusFactor,
      centerX: this.centerX,
      centerY: this.centerY,
      onLabelCreated: this.onLabelCreated,
      onAxisTapped: this.onAxisTapped,
      canRotateLabels: this.canRotateLabels,
      showFirstLabel: this.showFirstLabel,
      showLastLabel: this.showLastLabel,
      canScaleToFit: this.canScaleToFit,
      backgroundImage: this.backgroundImage,
      ranges: this.ranges,
      pointers: pointers ?? this.pointers,
      annotations: annotations ?? this.annotations,
      minimum: this.minimum,
      maximum: this.maximum,
      interval: this.interval,
      minorTicksPerInterval: this.minorTicksPerInterval,
      showLabels: this.showLabels,
      showAxisLine: this.showAxisLine,
      showTicks: this.showTicks,
      tickOffset: this.tickOffset,
      labelOffset: this.labelOffset,
      isInversed: this.isInversed,
      maximumLabels: this.maximumLabels,
      useRangeColorForAxis: this.useRangeColorForAxis,
      labelFormat: this.labelFormat,
      numberFormat: this.numberFormat,
      onCreateAxisRenderer: this.onCreateAxisRenderer,
      ticksPosition: this.ticksPosition,
      labelsPosition: this.labelsPosition,
      offsetUnit: this.offsetUnit,
      axisLabelStyle: this.axisLabelStyle,
      axisLineStyle: axisLineStyle ?? this.axisLineStyle,
      majorTickStyle: this.majorTickStyle,
      minorTickStyle: this.minorTickStyle,
    );
  }
}
