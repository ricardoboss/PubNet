import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_openbridge/components/parts/ship_side_painter.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

class Pitch extends StatefulWidget {
  final double value;
  final int extent;
  final double? recommendedExtent;
  final Color primary;
  final Color secondary;
  final Color rimColor;
  final Color rimBackground;

  Pitch({
    super.key,
    required this.value,
    required this.extent,
    this.recommendedExtent,
    this.primary = Colors.blue,
    Color? secondary,
    this.rimColor = Colors.grey,
    this.rimBackground = Colors.white,
  })  : secondary = secondary ?? primary.withOpacity(0.5),
        assert(extent <= 45, "extent cannot exceed 45°"),
        assert(recommendedExtent == null || recommendedExtent <= extent,
            "recommendedExtent cannot be greater than extent");

  @override
  State<Pitch> createState() => _PitchState();
}

class _PitchState extends State<Pitch> {
  @override
  Widget build(BuildContext context) {
    final axisExtent = widget.extent;
    final radianExtent = 2 * pi * (axisExtent / 360);
    final constrainedValue = clampDouble(
        widget.value, -widget.extent.toDouble(), widget.extent.toDouble());

    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final axisThickness = constraints.smallest.shortestSide / 15.0;

        // values determined using trial-and-error, don't ask
        final needleLength =
            max(0.0, 0.475 * (constraints.smallest.shortestSide - 75.0));

        final shipWidth = constraints.smallest.shortestSide * 3 / 7;
        // aspect ratio taken from openbridge design
        final shipHeight = shipWidth * 55 / 167;

        final axisRanges = <GaugeRange>[
          GaugeRange(
            startValue: -axisExtent * 0.99,
            endValue: axisExtent * 0.99,
            color: widget.rimBackground,
            startWidth: axisThickness - 3,
            endWidth: axisThickness - 3,
            rangeOffset: 1.5,
          ),
        ];

        final recommendedExtent = widget.recommendedExtent;
        if (recommendedExtent != null) {
          axisRanges.add(GaugeRange(
            startValue: -recommendedExtent,
            endValue: recommendedExtent,
            color: widget.secondary,
            startWidth: axisThickness - 6,
            endWidth: axisThickness - 6,
            rangeOffset: 3,
          ));
        }

        return Stack(
          alignment: Alignment.center,
          children: [
            Transform.rotate(
              angle: radianExtent * constrainedValue / widget.extent,
              child: CustomPaint(
                painter: ShipSidePainter(
                  borderColor: widget.rimColor,
                  backgroundColor: widget.rimBackground,
                ),
                child: SizedBox(
                  width: shipWidth,
                  height: shipHeight,
                ),
              ),
            ),
            SfRadialGauge(
              axes: [
                RadialAxis(
                  axisLineStyle: AxisLineStyle(
                    thickness: axisThickness,
                    color: widget.rimColor,
                  ),
                  ticksPosition: ElementsPosition.outside,
                  labelsPosition: ElementsPosition.outside,
                  tickOffset: 3.0,
                  minorTicksPerInterval: 0,
                  minimum: -widget.extent.toDouble(),
                  maximum: widget.extent.toDouble(),
                  interval: widget.extent.toDouble(),
                  majorTickStyle: MajorTickStyle(
                    color: widget.rimColor,
                  ),
                  showLastLabel: true,
                  startAngle: 180 - axisExtent.toDouble(),
                  endAngle: 180 + axisExtent.toDouble(),
                  ranges: axisRanges,
                  pointers: [
                    NeedlePointer(
                      value: widget.value,
                      needleColor: widget.primary,
                      knobStyle: KnobStyle(
                        color: widget.primary,
                        knobRadius: 5,
                        sizeUnit: GaugeSizeUnit.logicalPixel,
                      ),
                      needleLength: needleLength,
                      lengthUnit: GaugeSizeUnit.logicalPixel,
                      needleStartWidth: 2,
                      needleEndWidth: 2,
                    ),
                  ],
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}
