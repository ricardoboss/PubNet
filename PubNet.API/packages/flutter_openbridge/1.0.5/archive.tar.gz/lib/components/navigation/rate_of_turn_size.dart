enum RateOfTurnSize {
  small,
  medium,
  large,
}
