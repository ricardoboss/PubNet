enum HeadingVariation {
  normal,
  flat,
  classic,
}
