enum RateOfTurnVariation {
  circular,
  radial,
  flat,
}
