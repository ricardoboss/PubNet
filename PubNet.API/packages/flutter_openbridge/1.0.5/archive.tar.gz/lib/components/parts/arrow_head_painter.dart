import 'package:flutter/material.dart';

class ArrowHeadPainter extends CustomPainter {
  final Color color;
  final bool fill;

  ArrowHeadPainter({this.color = Colors.black, this.fill = true});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = size.shortestSide / 10
      ..strokeJoin = StrokeJoin.round
      ..strokeCap = StrokeCap.round
      ..style = fill ? PaintingStyle.fill : PaintingStyle.stroke;

    final path = getTrianglePath(size.width, size.height);
    canvas.drawPath(path, paint);
  }

  Path getTrianglePath(double x, double y) {
    return Path()
      ..moveTo(x / 2, 0)
      ..lineTo(x, y)
      ..lineTo(x / 2, y * (7 / 8))
      ..lineTo(0, y)
      ..lineTo(x / 2, 0);
  }

  @override
  bool shouldRepaint(ArrowHeadPainter oldDelegate) {
    return oldDelegate.color != color || oldDelegate.fill != fill;
  }
}
