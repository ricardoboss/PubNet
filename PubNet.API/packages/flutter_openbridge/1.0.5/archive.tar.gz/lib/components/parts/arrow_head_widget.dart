import 'package:flutter/material.dart';
import 'package:flutter_openbridge/components/parts/arrow_head_painter.dart';

class ArrowHeadWidget extends StatelessWidget {
  static const aspectRatio = 0.72916666666;

  final Color color;
  final double dimension;
  final bool fill;

  const ArrowHeadWidget({
    super.key,
    required this.color,
    required this.dimension,
    this.fill = true,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: ArrowHeadPainter(color: color, fill: fill),
      child: SizedBox(
        height: dimension / aspectRatio,
        width: dimension,
      ),
    );
  }
}
