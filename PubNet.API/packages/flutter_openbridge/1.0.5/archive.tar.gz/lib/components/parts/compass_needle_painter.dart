import 'package:flutter/material.dart';

class CompassNeedlePainter extends CustomPainter {
  final Color color;

  CompassNeedlePainter({this.color = Colors.black});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..strokeJoin = StrokeJoin.round
      ..strokeCap = StrokeCap.round
      ..strokeWidth = size.shortestSide / 8
      ..color = color;

    canvas.drawPath(getFilledPath(size.width, size.height), paint..style = PaintingStyle.fill);
    canvas.drawPath(getOutlinedPath(size.width, size.height), paint..style = PaintingStyle.stroke);
  }

  Path getFilledPath(double x, double y) {
    return Path()
      ..moveTo(x / 2, 0)
      ..lineTo(x, y / 2)
      ..lineTo(x / 2, y / 2 + y / 50)
      ..lineTo(0, y / 2)
      ..lineTo(x / 2, 0);
  }

  Path getOutlinedPath(double x, double y) {
    return Path()
      ..moveTo(x / 2, 0)
      ..lineTo(x, y / 2)
      ..lineTo(x / 2, y)
      ..lineTo(0, y / 2)
      ..lineTo(x / 2, 0)
    ;
  }

  @override
  bool shouldRepaint(CompassNeedlePainter oldDelegate) {
    return oldDelegate.color != color;
  }
}
