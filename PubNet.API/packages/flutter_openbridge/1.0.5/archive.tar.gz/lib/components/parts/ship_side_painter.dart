import 'package:flutter/material.dart';

class ShipSidePainter extends CustomPainter {
  final Color borderColor;
  final Color backgroundColor;

  ShipSidePainter({
    this.borderColor = Colors.black,
    this.backgroundColor = Colors.white,
  });

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawPath(
      getShipPathPath(size.width, size.height),
      Paint()
        ..color = backgroundColor
        ..style = PaintingStyle.fill,
    );

    final strokePaint = Paint()
      ..color = borderColor
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = size.shortestSide / 35
      ..style = PaintingStyle.stroke;

    canvas.drawPath(
      getMiddleLine(size.width, size.height),
      strokePaint,
    );

    canvas.drawPath(
      getShipPathPath(size.width, size.height),
      strokePaint,
    );
  }

  Path getShipPathPath(double x, double y) {
    return Path()
      ..moveTo(0, 0)
      ..lineTo(x, 0)
      ..lineTo(x, y)
      ..lineTo(y, y)
      ..cubicTo(0.5 * y, y, 0, 0.5 * y, 0, 0);
  }

  Path getMiddleLine(double x, double y) {
    return Path()
      ..moveTo(x / 2, 0)
      ..lineTo(x / 2, y);
  }

  @override
  bool shouldRepaint(ShipSidePainter oldDelegate) {
    return oldDelegate.borderColor != borderColor ||
        oldDelegate.backgroundColor != backgroundColor;
  }
}
