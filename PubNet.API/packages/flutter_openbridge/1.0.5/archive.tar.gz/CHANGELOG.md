## 1.0.4

* Added labels and ticks to RateOfTurn component if the size is larger than `small`.
* Increased Speedometer axis thickness

## 1.0.3

* Small style changes to Roll and Pitch components
* RateOfTurn radial variation extent is now adjustable (was fixed to 30°)

## 1.0.2

* Added more metadata

## 1.0.1

* Fixed size calculation for Heading widget
* Updated README and added an example

## 1.0.0

* Initial release
* New widgets:
  * RateOfTurn
  * Heading
  * Pitch
  * Roll
  * Speedometer
