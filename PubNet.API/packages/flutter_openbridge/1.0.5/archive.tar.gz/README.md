Provides Flutter widgets for different components of the [OpenBridge] design guideline.

## Components

The OpenBridge specification defines components as elements that are used to make up a user
interface.

A subset of the defined components has been implemented as ready-to-use Flutter widgets.

### Navigation

Navigation components are instruments and graphical elements like thruster representation, compass
and boat representation.

Available components:

- Speedometer
- Roll & Pitch
- Rate Of Turn
- Heading

![An image of all available navigation components](images/navigation-components.png)

## Getting started

Simply install it:

`flutter pub add flutter_openbridge --hosted-url https://dartpack.trenz.cloud`

And use its components:

```dart
SizedBox(
  width: 200,
  height: 200,
  child: Speedometer(
    value: _value,
    extent: 40,
  ),
),
```

## Usage

Some components support different sizes and variations:

```dart
// Results in an arc that fills as the value gets larger
RateOfTurn(
  value: ...
  extent: ...
  variation: RateOfTurnVariation.radial,
)

// A circle with dots that spin faster as the value gets larger
RateOfTurn(
  value: ...
  extent: ...
  variation: RateOfTurnVariation.circular,
)
```

```dart
Heading(
  headingTrue: ...
  size: HeadingSize.medium, // default size
)

Heading(
  headingTrue: ...
  size: HeadingSize.small, // less labels, only one big arrow head
)
```

## Additional information

TODO: Tell users more about the package: where to find more information, how to
contribute to the package, how to file issues, what response they can expect
from the package authors, and more.

[OpenBridge]: https://www.openbridge.no/guidelines/guideline