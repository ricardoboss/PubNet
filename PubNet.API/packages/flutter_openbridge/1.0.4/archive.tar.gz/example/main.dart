import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_openbridge/flutter_openbridge.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  double _value = 0;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: SizedBox(
            width: 200,
            height: 200,
            child: Speedometer(
              value: _value,
              extent: 40,
            ),
          ),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () =>
              setState(() => _value = (Random()).nextDouble() * 40),
          child: const Icon(Icons.casino_outlined),
        ),
      ),
    );
  }
}
