import 'package:flutter/material.dart';
import 'package:flutter_openbridge/components/parts/triangle_painter.dart';

class TriangleWidget extends StatelessWidget {
  final Color color;
  final double width;
  final double height;
  final Widget? child;

  const TriangleWidget({
    super.key,
    this.child,
    required this.color,
    required this.width,
    required this.height,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: TrianglePainter(color: color),
      child: SizedBox(
        width: width,
        height: height,
        child: Center(child: child),
      ),
    );
  }
}
