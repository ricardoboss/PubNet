import 'package:flutter/material.dart';
import 'package:flutter_openbridge/components/parts/compass_needle_painter.dart';

class CompassNeedleWidget extends StatelessWidget {
  final Color color;
  final double width;
  final double height;
  final Widget? child;

  const CompassNeedleWidget({
    super.key,
    this.child,
    required this.color,
    required this.width,
    required this.height,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: CompassNeedlePainter(color: color),
      child: SizedBox(
        width: width,
        height: height,
        child: Center(child: child),
      ),
    );
  }
}
