import 'package:flutter/material.dart';
import 'package:flutter_openbridge/components/parts/arrow_head_widget.dart';

class ArrowWidget extends StatelessWidget {
  final Color color;
  final double width;
  final double height;
  final double headSize;
  final bool fillHead;

  const ArrowWidget({
    super.key,
    required this.color,
    required this.width,
    required this.height,
    required this.headSize,
    this.fillHead = true,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      width: headSize,
      child: Stack(
        alignment: Alignment.topCenter,
        children: [
          ArrowHeadWidget(
            color: color,
            dimension: headSize,
            fill: fillHead,
          ),
          Transform.translate(
            offset: Offset(0, headSize / 2),
            child: Container(
              height: height - (headSize / 2),
              width: width,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
