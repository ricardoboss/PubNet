import 'dart:math';

import 'package:flutter/material.dart';

class CirclePatternPainter extends CustomPainter {
  final Color dotColor;
  final Color rimColor;
  final Color rimBackground;
  final double rimThickness;
  final double dotRadius;
  final int count;
  final double offset;

  CirclePatternPainter({
    required this.count,
    required this.dotRadius,
    required this.dotColor,
    required this.rimThickness,
    required this.rimColor,
    required this.rimBackground,
    this.offset = 0.0,
  });

  @override
  bool shouldRepaint(CirclePatternPainter oldDelegate) {
    return oldDelegate.dotColor != dotColor ||
        oldDelegate.rimColor != rimColor ||
        oldDelegate.rimBackground != rimBackground ||
        oldDelegate.rimThickness != rimThickness ||
        oldDelegate.dotRadius != dotRadius ||
        oldDelegate.count != count ||
        oldDelegate.offset != offset;
  }

  @override
  void paint(Canvas canvas, Size size) {
    _paintRim(canvas, size);
    _paintDots(canvas, size);
  }

  void _paintRim(Canvas canvas, Size size) {
    final rimBackgroundPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = rimThickness * 2
      ..color = rimBackground;

    canvas.drawOval(
      Rect.fromLTWH(
        rimThickness,
        rimThickness,
        size.width - 2 * rimThickness,
        size.height - 2 * rimThickness,
      ),
      rimBackgroundPaint,
    );

    final rimPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = rimColor;

    canvas.drawOval(
      Rect.fromLTWH(0, 0, size.width, size.height),
      rimPaint,
    );

    canvas.drawOval(
      Rect.fromLTWH(
        rimThickness * 2,
        rimThickness * 2,
        size.width - 4 * rimThickness,
        size.height - 4 * rimThickness,
      ),
      rimPaint,
    );
  }

  void _paintDots(Canvas canvas, Size size) {
    final circlePaint = Paint()
      ..style = PaintingStyle.fill
      ..color = dotColor;

    final dotDiameter = rimThickness * 2;
    final dotContainerWidth = size.width - dotDiameter;
    final dotContainerHeight = size.height - dotDiameter;
    final halfWidth = dotContainerWidth / 2;
    final halfHeight = dotContainerHeight / 2;
    final arcsPerCircle = pi * 2 / count;

    for (var i = 0; i < count; i++) {
      final angle = offset + arcsPerCircle * i;
      final pos = Offset(
        rimThickness + (halfWidth - halfWidth * cos(angle)),
        rimThickness + (halfHeight - halfHeight * sin(angle)),
      );
      canvas.drawCircle(pos, dotRadius, circlePaint);
    }
  }
}
