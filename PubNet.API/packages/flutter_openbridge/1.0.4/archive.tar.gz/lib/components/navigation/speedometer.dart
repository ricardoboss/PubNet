import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_openbridge/components/navigation/speedometer_variation.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

class Speedometer extends StatefulWidget {
  final SpeedometerVariation variation;
  final double value;
  final int extent;
  final Color primary;
  final Color rimColor;
  final Color rimBackground;

  const Speedometer({
    super.key,
    required this.value,
    required this.extent,
    this.primary = Colors.blue,
    this.rimColor = Colors.grey,
    this.rimBackground = Colors.white,
    this.variation = SpeedometerVariation.radial,
  }) : assert(extent >= 0, "extent cannot be negative");

  @override
  State<Speedometer> createState() => _SpeedometerState();
}

class _SpeedometerState extends State<Speedometer> {
  @override
  Widget build(BuildContext context) {
    final constrainedExtent = widget.extent - (widget.extent % 4);
    final almostMinExtent = constrainedExtent * 0.001;
    final nearlyMinExtent = constrainedExtent * 0.002;
    final closelyMinExtent = constrainedExtent * 0.003;
    final almostMaxExtent = constrainedExtent * 0.999;
    final nearlyMaxExtent = constrainedExtent * 0.998;

    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        final axisThickness = constraints.smallest.shortestSide / 20;

        final ranges = <GaugeRange>[
          GaugeRange(
            color: widget.rimBackground,
            startValue: almostMinExtent,
            endValue: almostMaxExtent,
            startWidth: axisThickness - 2,
            endWidth: axisThickness - 2,
            rangeOffset: 1,
          ),
        ];
        final pointers = <GaugePointer>[];

        switch (widget.variation) {
          case SpeedometerVariation.radial:
            ranges.add(GaugeRange(
              startValue: nearlyMinExtent,
              endValue:
                  min(max(widget.value, closelyMinExtent), nearlyMaxExtent),
              startWidth: axisThickness - 4,
              endWidth: axisThickness - 4,
              color: widget.primary,
              rangeOffset: 2,
            ));
            break;
          case SpeedometerVariation.needle:
            // formula determined by trial-and-error so that the needle
            // almost touches the outer edge of the axis track
            final needleLength = max(0.0, 0.466 * (constraints.smallest.shortestSide - 55));

            pointers.add(NeedlePointer(
              value: widget.value,
              needleLength: needleLength,
              lengthUnit: GaugeSizeUnit.logicalPixel,
              knobStyle: KnobStyle(
                color: widget.primary,
                knobRadius: 5,
                sizeUnit: GaugeSizeUnit.logicalPixel,
              ),
              needleColor: widget.primary,
              needleStartWidth: 1,
              needleEndWidth: 5,
            ));
            break;
        }

        return SfRadialGauge(
          axes: [
            RadialAxis(
              startAngle: 135,
              endAngle: 45,
              minimum: 0,
              maximum: constrainedExtent.toDouble(),
              ranges: ranges,
              pointers: pointers,
              axisLineStyle: AxisLineStyle(
                color: widget.rimColor,
                thickness: axisThickness,
              ),
              majorTickStyle: MajorTickStyle(
                color: widget.rimColor,
                length: axisThickness / 3,
              ),
              interval: constrainedExtent / 4,
              showLastLabel: true,
              labelsPosition: ElementsPosition.outside,
              ticksPosition: ElementsPosition.outside,
              minorTicksPerInterval: 0,
              tickOffset: 4,
              labelOffset: 8,
            ),
          ],
        );
      },
    );
  }
}
