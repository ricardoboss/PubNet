import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_openbridge/components/navigation/heading_size.dart';
import 'package:flutter_openbridge/components/navigation/heading_variation.dart';
import 'package:flutter_openbridge/components/parts/arrow_head_widget.dart';
import 'package:flutter_openbridge/components/parts/arrow_widget.dart';
import 'package:flutter_openbridge/components/parts/compass_needle_widget.dart';
import 'package:flutter_openbridge/components/parts/triangle_widget.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

class Heading extends StatefulWidget {
  final HeadingVariation variation;
  final HeadingSize size;
  final double headingTrue;
  final double? courseOverGround;
  final double? headingSetPoint;
  final Color primary;
  final Color secondary;
  final Color rimColor;
  final Color rimBackground;

  const Heading({
    super.key,
    required this.headingTrue,
    this.courseOverGround,
    this.headingSetPoint,
    this.variation = HeadingVariation.normal,
    this.size = HeadingSize.medium,
    this.primary = Colors.blue,
    this.secondary = Colors.indigo,
    this.rimColor = Colors.grey,
    this.rimBackground = Colors.white,
  });

  @override
  State<Heading> createState() => _HeadingState();
}

class _HeadingState extends State<Heading> {
  double get normalizedHeadingTrue => widget.headingTrue % 360;

  double get normalizedHeadingTrueOpposite => (widget.headingTrue + 180) % 360;

  double? get normalizedCourseOverGround =>
      widget.courseOverGround == null ? null : widget.courseOverGround! % 360;

  double? get normalizedHeadingSetPoint =>
      widget.headingSetPoint == null ? null : widget.headingSetPoint! % 360;

  @override
  Widget build(BuildContext context) {
    switch (widget.variation) {
      case HeadingVariation.normal:
      case HeadingVariation.classic:
        return _buildNormalVariation(context);
      case HeadingVariation.flat:
        return _buildFlatVariation(context);
    }
  }

  Widget _buildNormalVariation(BuildContext context) {
    return LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
      final diameter = constraints.smallest.shortestSide;
      final stackChildren = <Widget>[];
      final axes = <RadialAxis>[];
      final EdgeInsets padding;
      final double rimThickness;

      if (widget.size == HeadingSize.small) {
        padding = EdgeInsets.all(diameter / 10);
        rimThickness = 1;
        final realDiameter = diameter - padding.vertical;

        final smallPointerDimension = realDiameter * 2 / 5;
        final smallPointerOffset = realDiameter * 3 / 7;

        final smallPointer = WidgetPointer(
          offset: smallPointerOffset,
          value: normalizedHeadingTrue,
          child: Transform.rotate(
            angle: normalizedHeadingTrue * pi / 180,
            child: ArrowHeadWidget(
              color: widget.primary,
              dimension: smallPointerDimension,
            ),
          ),
        );

        final northAnnotationHeight = padding.top;
        final positionShift = northAnnotationHeight / realDiameter;
        final northAnnotation = GaugeAnnotation(
          angle: 270,
          positionFactor: 1 + positionShift,
          widget: TriangleWidget(
            color: Colors.black,
            width: northAnnotationHeight * 1.5,
            height: northAnnotationHeight,
          ),
        );

        final smallAxisLineStyle = AxisLineStyle(
          color: widget.rimColor,
          thickness: rimThickness,
        );

        final tickLength = realDiameter / 25;
        final tickStyle = MajorTickStyle(
          color: widget.rimColor,
          length: tickLength,
        );

        axes.add(
          RadialAxis(
            startAngle: 270,
            endAngle: 270,
            minimum: 0,
            maximum: 360,
            majorTickStyle: tickStyle,
            minorTicksPerInterval: 0,
            tickOffset: tickLength,
            interval: 45,
            showLabels: false,
            axisLineStyle: smallAxisLineStyle,
            pointers: [
              smallPointer,
            ],
            annotations: [
              northAnnotation,
            ],
          ),
        );
      } else {
        padding = EdgeInsets.all(diameter / 10);
        final outerDiameter = diameter - padding.vertical;
        rimThickness = outerDiameter / 15;
        final innerDiameter = outerDiameter - (3 * rimThickness) - 2;

        final pointers = <GaugePointer>[];

        if (widget.variation == HeadingVariation.classic) {
          pointers.add(
            WidgetPointer(
              offset: 1 - (rimThickness / innerDiameter),
              offsetUnit: GaugeSizeUnit.factor,
              value: normalizedHeadingTrue,
              child: Transform.rotate(
                angle: normalizedHeadingTrue * pi / 180,
                child: CompassNeedleWidget(
                  color: widget.primary,
                  width: rimThickness,
                  height: innerDiameter,
                ),
              ),
            ),
          );
        } else {
          // knob in the middle
          stackChildren.add(
            Center(
              child: ClipOval(
                child: Container(
                  color: widget.primary,
                  width: rimThickness * 2 / 3,
                  height: rimThickness * 2 / 3,
                ),
              ),
            ),
          );

          // main pointer for heading
          pointers.add(
            WidgetPointer(
              offset: 0.5,
              offsetUnit: GaugeSizeUnit.factor,
              value: normalizedHeadingTrue,
              child: Transform.rotate(
                angle: normalizedHeadingTrue * pi / 180,
                child: ArrowWidget(
                  color: widget.primary,
                  width: 4,
                  height: innerDiameter / 2,
                  headSize: rimThickness * 1.5,
                ),
              ),
            ),
          );

          // second part of main pointer, points in the opposite direction
          pointers.add(
            WidgetPointer(
              offset: 0.5,
              offsetUnit: GaugeSizeUnit.factor,
              value: normalizedHeadingTrueOpposite,
              child: Transform.rotate(
                angle: normalizedHeadingTrueOpposite * pi / 180,
                child: Container(
                  color: widget.primary,
                  width: 2,
                  height: innerDiameter / 2,
                ),
              ),
            ),
          );
        }

        // course over ground pointer
        final courseOverGround = normalizedCourseOverGround;
        if (courseOverGround != null) {
          pointers.add(
            WidgetPointer(
              offset: 0.5,
              offsetUnit: GaugeSizeUnit.factor,
              value: courseOverGround,
              child: Transform.rotate(
                angle: courseOverGround * pi / 180,
                child: ArrowWidget(
                  color: widget.primary,
                  width: 0,
                  height: innerDiameter / 2,
                  headSize: rimThickness * 1.5,
                  fillHead: false,
                ),
              ),
            ),
          );
        }

        // heading set point pointer
        final headingSetPoint = normalizedHeadingSetPoint;
        if (headingSetPoint != null) {
          pointers.add(
            MarkerPointer(
              color: widget.secondary,
              value: headingSetPoint,
              markerType: MarkerType.invertedTriangle,
              markerHeight: rimThickness,
              markerWidth: rimThickness,
            ),
          );
        }

        final annotationPadding = padding.top / 4;
        final northAnnotationHeight = padding.top;
        final annotationPositionShift =
            (northAnnotationHeight + annotationPadding) / outerDiameter;
        final annotationFontSize = northAnnotationHeight * 0.5;
        final minorAnnotationTextStyle = TextStyle(
          color: Colors.black,
          fontWeight: FontWeight.bold,
          fontSize: annotationFontSize,
        );

        final northAnnotation = GaugeAnnotation(
          angle: 270,
          positionFactor: 1 + annotationPositionShift,
          widget: TriangleWidget(
            color: Colors.black,
            width: northAnnotationHeight * 1.5,
            height: northAnnotationHeight,
            child: Text(
              "N",
              style: minorAnnotationTextStyle.copyWith(color: Colors.white),
            ),
          ),
        );

        final eastAnnotation = GaugeAnnotation(
          angle: 0,
          positionFactor: 1 + annotationPositionShift,
          widget: Text(
            "E",
            style: minorAnnotationTextStyle,
          ),
        );

        final southAnnotation = GaugeAnnotation(
          angle: 90,
          positionFactor: 1 + annotationPositionShift,
          widget: Text(
            "S",
            style: minorAnnotationTextStyle,
          ),
        );

        final westAnnotation = GaugeAnnotation(
          angle: 180,
          positionFactor: 1 + annotationPositionShift,
          widget: Text(
            "W",
            style: minorAnnotationTextStyle,
          ),
        );

        // rim background
        axes.add(
          RadialAxis(
            startAngle: 270,
            endAngle: 270,
            minimum: 0,
            maximum: 360,
            showLabels: false,
            showTicks: false,
            axisLineStyle: AxisLineStyle(
              color: widget.rimBackground,
              thickness: rimThickness,
            ),
            pointers: pointers,
          ),
        );

        // inner rim
        axes.add(
          RadialAxis(
            startAngle: 270,
            endAngle: 270,
            minimum: 0,
            maximum: 360,
            showLabels: false,
            showTicks: true,
            ticksPosition: ElementsPosition.outside,
            minorTicksPerInterval: 0,
            majorTickStyle: MajorTickStyle(
              length: rimThickness + 1,
              color: Colors.transparent,
            ),
            axisLineStyle: AxisLineStyle(
              thickness: 1,
              color: widget.rimColor,
            ),
          ),
        );

        // outer rim and rim ticks
        axes.add(RadialAxis(
          startAngle: 270,
          endAngle: 270,
          minimum: 0,
          maximum: 360,
          showLabels: false,
          interval: 45,
          minorTicksPerInterval: 0,
          tickOffset: 1,
          majorTickStyle: MajorTickStyle(
            length: rimThickness - 3,
            color: widget.rimColor,
          ),
          axisLineStyle: AxisLineStyle(
            thickness: 1,
            color: widget.rimColor,
          ),
          annotations: [
            northAnnotation,
            eastAnnotation,
            southAnnotation,
            westAnnotation,
          ],
        ));
      }

      stackChildren.add(SfRadialGauge(axes: axes));

      return Padding(
        padding: padding,
        child: Stack(
          children: stackChildren,
        ),
      );
    });
  }

  Widget _buildFlatVariation(BuildContext context) {
    return const Center(child: Text("TODO"));
  }
}
