import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_openbridge/components/navigation/rate_of_turn_size.dart';
import 'package:flutter_openbridge/components/navigation/rate_of_turn_variation.dart';
import 'package:flutter_openbridge/components/parts/circle_pattern_painter.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

class RateOfTurn extends StatefulWidget {
  final double value;
  final double extent;
  final int circularDots;
  final double radialExtent;
  final Color primary;
  final Color rimColor;
  final Color rimBackground;
  final RateOfTurnVariation variation;
  final RateOfTurnSize size;

  const RateOfTurn({
    super.key,
    required this.value,
    required this.extent,
    required this.variation,
    this.primary = Colors.blue,
    this.rimColor = Colors.grey,
    this.rimBackground = Colors.white,
    this.circularDots = 5,
    this.radialExtent = 60,
    this.size = RateOfTurnSize.medium,
  }) : assert(extent > 0, "extent must be greater than 0");

  @override
  State<RateOfTurn> createState() => _RateOfTurnState();
}

class _RateOfTurnState extends State<RateOfTurn>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();

    var last = AnimationStatus.dismissed;
    _controller = AnimationController(vsync: this)
      ..duration = const Duration(seconds: 1)
      ..reverseDuration = const Duration(seconds: 1)
      ..addStatusListener((status) {
        if (last != status) {
          last = status;

          if (last == AnimationStatus.completed && widget.value > 0) {
            _controller.forward(from: _controller.lowerBound);
          } else if (last == AnimationStatus.dismissed && widget.value < 0) {
            _controller.reverse(from: _controller.upperBound);
          } else if (widget.value == 0) {
            _controller.stop();
          }
        }
      });
  }

  @override
  void dispose() {
    _controller.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    switch (widget.variation) {
      case RateOfTurnVariation.circular:
        return _buildCircular(context);
      case RateOfTurnVariation.radial:
        return _buildRadial(context);
      case RateOfTurnVariation.flat:
        return _buildFlat(context);
    }
  }

  Widget _buildCircular(BuildContext context) {
    final sideLength = MediaQuery.of(context).size.shortestSide;

    if (widget.value != 0) {
      final d = Duration(
          microseconds: (Duration.microsecondsPerSecond *
                  widget.extent /
                  widget.value.abs())
              .round());
      if (widget.value < 0) {
        _controller.reverseDuration = d;
        _controller.reverse(from: _controller.value);
      } else {
        _controller.duration = d;
        _controller.forward(from: _controller.value);
      }
    } else {
      _controller.stop();
    }

    return RotationTransition(
      turns: Tween<double>(begin: 0, end: 1).animate(_controller),
      child: SizedBox.square(
        dimension: sideLength,
        child: Stack(
          alignment: Alignment.center,
          children: [
            SizedBox.square(
              dimension: sideLength,
              child: CustomPaint(
                painter: CirclePatternPainter(
                  offset: pi / 2,
                  count: widget.circularDots,
                  dotColor: widget.primary,
                  rimThickness: sideLength / 50,
                  dotRadius: sideLength / 50 - 2,
                  rimColor: widget.rimColor,
                  rimBackground: widget.rimBackground,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRadial(BuildContext context) {
    final showAnnotations = widget.size != RateOfTurnSize.small;

    return LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
      final axisThickness = constraints.smallest.shortestSide / 10;

      return SfRadialGauge(
        axes: [
          RadialAxis(
            canScaleToFit: true,
            showLabels: showAnnotations,
            labelsPosition: ElementsPosition.outside,
            showLastLabel: showAnnotations,
            showTicks: showAnnotations,
            tickOffset: 4,
            ticksPosition: ElementsPosition.outside,
            majorTickStyle: MajorTickStyle(
              color: widget.rimColor,
              length: axisThickness / 4,
            ),
            minorTicksPerInterval: 0,
            interval: widget.extent / 3,
            startAngle: 270 - widget.radialExtent,
            endAngle: 270 + widget.radialExtent,
            minimum: -widget.extent,
            maximum: widget.extent,
            axisLineStyle: AxisLineStyle(
              color: widget.rimColor,
              thickness: axisThickness,
            ),
            ranges: [
              GaugeRange(
                startValue: -widget.extent * 0.997,
                endValue: widget.extent * 0.997,
                color: widget.rimBackground,
                startWidth: axisThickness - 2,
                endWidth: axisThickness - 2,
                rangeOffset: 1,
              ),
              GaugeRange(
                startValue: min(widget.value, 0),
                endValue: max(widget.value, 0),
                color: widget.primary,
                startWidth: axisThickness - 4,
                endWidth: axisThickness - 4,
                rangeOffset: 2,
              ),
            ],
          ),
        ],
      );
    });
  }

  Widget _buildFlat(BuildContext context) {
    const largeSizeTicks = 4;

    return LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
      final height = constraints.maxHeight;
      final axisThickness = height / 5.0;

      return SfLinearGauge(
        minimum: -widget.extent,
        maximum: widget.extent,
        isMirrored: true,
        interval: widget.extent / largeSizeTicks,
        onGenerateLabels: () {
          if (widget.size == RateOfTurnSize.small) {
            return [];
          }

          if (widget.size == RateOfTurnSize.medium) {
            return [
              LinearAxisLabel(
                  text: (-widget.extent).toStringAsFixed(0),
                  value: -widget.extent),
              const LinearAxisLabel(text: "0", value: 0),
              LinearAxisLabel(
                  text: widget.extent.toStringAsFixed(0), value: widget.extent),
            ];
          }

          final labels = <LinearAxisLabel>[];
          const totalTicks = largeSizeTicks * 2;
          for (var i = 0; i <= totalTicks; i++) {
            final value = (2 * widget.extent / totalTicks) * i - widget.extent;

            labels.add(
                LinearAxisLabel(text: value.toStringAsFixed(0), value: value));
          }
          return labels;
        },
        minorTicksPerInterval: widget.size == RateOfTurnSize.medium ? 3 : 0,
        tickOffset: axisThickness / 5,
        labelOffset: axisThickness * 2 / 5,
        majorTickStyle: LinearTickStyle(
          color: widget.rimColor,
          length: axisThickness * 2 / 5,
        ),
        axisTrackStyle: LinearAxisTrackStyle(
          thickness: axisThickness,
          color: widget.rimBackground,
          borderColor: widget.rimColor,
          borderWidth: 1,
        ),
        ranges: [
          LinearGaugeRange(
            endWidth: axisThickness,
            startWidth: axisThickness,
            startValue: min(widget.value, 0),
            endValue: max(widget.value, 0),
            position: LinearElementPosition.cross,
            color: widget.primary,
          ),
        ],
        markerPointers: [
          LinearWidgetPointer(
            value: 0,
            child: Container(
              height: axisThickness,
              width: 3,
              color: widget.rimColor,
            ),
          ),
        ],
      );
    });
  }
}
