enum SpeedometerVariation {
  radial,
  needle,
}
