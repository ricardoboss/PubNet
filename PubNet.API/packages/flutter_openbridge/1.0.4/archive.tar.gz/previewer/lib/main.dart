import 'package:flutter/material.dart';
import 'package:flutter_openbridge/flutter_openbridge.dart';

void main() {
  runApp(const MyApp());
}

class SizedSlider extends StatefulWidget {
  final double sideLength;
  final double min;
  final double max;
  final double? initial;
  final void Function(double value) onChanged;

  const SizedSlider({
    super.key,
    required this.sideLength,
    required this.min,
    required this.max,
    required this.onChanged,
    this.initial,
  });

  @override
  State<SizedSlider> createState() => _SizedSliderState();
}

class _SizedSliderState extends State<SizedSlider> {
  double _value = 0;

  @override
  void initState() {
    super.initState();

    _value = widget.initial ?? 0;
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: widget.sideLength - 50,
          child: Slider(
            value: _value,
            min: widget.min,
            max: widget.max,
            onChanged: (v) => setState(() {
              _value = _value = v;

              widget.onChanged(_value);
            }),
          ),
        ),
        Text(_value.toStringAsFixed(2)),
      ],
    );
  }
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  double _extent = 30;
  double _extent2 = 30;
  double _value = 0;
  double _value2 = 0;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SafeArea(
          child: SingleChildScrollView(
            child: Builder(builder: (context) {
              final size = MediaQuery.of(context).size;
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Wrap(
                    children: [
                      SizedBox(
                        width: size.width / 3,
                        height: size.width / 3,
                        child: Speedometer(
                          value: _value,
                          extent: _extent.round(),
                          variation: SpeedometerVariation.needle,
                        ),
                      ),
                      SizedBox(
                        width: size.width / 3,
                        height: size.width / 3,
                        child: Roll(
                          value: _value,
                          extent: _extent.round(),
                        ),
                      ),
                      SizedBox(
                        width: size.width / 3,
                        height: size.width / 3,
                        child: Pitch(
                          value: _value,
                          extent: _extent.round(),
                        ),
                      ),
                      SizedBox(
                        width: size.width / 3,
                        height: size.width / 3,
                        child: RateOfTurn(
                          value: _value,
                          extent: _extent,
                          radialExtent: _extent2,
                          variation: RateOfTurnVariation.radial,
                        ),
                      ),
                      SizedBox(
                        width: size.width / 3,
                        height: size.width / 3,
                        child: Heading(
                          headingTrue: _value,
                          variation: HeadingVariation.normal,
                        ),
                      ),
                    ],
                  ),
                  Padding(padding: const EdgeInsets.all(15), child: Container(color: Colors.grey, height: 1)),
                  SizedSlider(
                    sideLength: size.width,
                    min: -_extent,
                    max: _extent,
                    initial: _value,
                    onChanged: (a) => setState(() => _value = a),
                  ),
                  SizedSlider(
                    sideLength: size.width,
                    min: 10,
                    max: 45,
                    initial: _extent,
                    onChanged: (a) => setState(() => _extent = a),
                  ),
                  Padding(padding: const EdgeInsets.all(15), child: Container(color: Colors.grey, height: 1)),
                  SizedSlider(
                    sideLength: size.width,
                    min: -_extent2,
                    max: _extent2,
                    initial: _value2,
                    onChanged: (a) => setState(() => _value2 = a),
                  ),
                  SizedSlider(
                    sideLength: size.width,
                    min: 30,
                    max: 180,
                    initial: _extent2,
                    onChanged: (a) => setState(() => _extent2 = a),
                  ),
                ],
              );
            }),
          ),
        ),
      ),
    );
  }
}
