package com.example.previewer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
